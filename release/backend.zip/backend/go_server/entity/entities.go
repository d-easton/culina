package entity

type Recipe struct {
	ID          int64               `json:"id"`
	Email       string              `json:"email"`
	Author      string              `json:"author"`
	Title       string              `json:"title"`
	Public      bool                `json:"public"`
	Likes       int64               `json:"likes"`
	Dislikes    int64               `json:"dislikes"`
	Category    string              `json:"category"`
	Liked       interface{}         `json:"liked"`
	Disliked    interface{}         `json:"disliked"`
	Ingredients []Commentconnection `json:"ingredients"`
	Steps       []Commentconnection `json:"steps"`
}

type Commentconnection struct {
	Text     string   `json:"text"`
	Comments []string `json:"comments"`
}

type User struct {
	Email string `json:"email"`
}

type GroceryList struct {
	ID          int64       `json:"id"`
	Email       string      `json:"email"`
	Ingredients interface{} `json:"ingredients"`
}
