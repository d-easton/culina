import React from 'react';
import EditRecipeCard from './RecipeCard.js';
const axios = require('axios');


const proxyurl = "https://cors-anywhere.herokuapp.com/";
const url = "http://35.193.28.175:8085/recipe"; 
const url2 = "http://35.193.28.175:8085/crecipe"; 
const k = proxyurl + url
const j = proxyurl + url2

fetch(k) // https://cors-anywhere.herokuapp.com/https://example.com
.then(response => response.json())
.then(recipe => console.log(recipe))
.catch(() => console.log("Can’t access " + url + " response. Blocked by browser?"))



fetch(k)
  .then(response => response.json())
  .then(json => {
      console.log(json)
  })

  //for creating a recipe
axios
    .post(j, {
            "title": "nov gucci",
            "text": "nov flex"
        }
    )
    .then(response => console.log(response))
    .catch(err => console.log('err', err));
      
// for getting a recipe
axios.get(k, {
    method: 'GET',
    mode: 'cors',
    headers: { 'Access-Control-Allow-Origin': true },
}).then(res => {
    const photos = res.data;
    console.log(res)
    });
    


const MainPage = ({handleSignout}) => {

    const recipes = {  test: 'foo'  }; 

    let recipeCards = [];

    /*
    for (let key in recipes) {
        recipeCards.push(
          //  <EditRecipeCard recipe={recipes[key]} key={key}/>
        );
    }
    */

    return (

        <section className="main">
            <nav>
                <h2> Welcome</h2>
                <button onClick={handleSignout}> Logout </button>

                <button> Show Recipes </button>

            </nav>
            {recipeCards}
        </section>    
    );

};

export default MainPage;